from datetime import datetime

from sqlalchemy.orm import Session

from models import ActionItem, Interaction, Milestone, StageChangeLog, Target


def create_target(
    db: Session,
    target_code: str,
    project_name: str,
    sector: str | None = None,
    country: str | None = None,
    deal_owner: str | None = None,
    priority_tier: str = "Watchlist",
    strategic_rationale: str | None = None,
) -> Target:
    target = Target(
        target_code=target_code.strip(),
        project_name=project_name.strip(),
        sector=sector or None,
        country=country or None,
        deal_owner=deal_owner or None,
        priority_tier=priority_tier,
        strategic_rationale=strategic_rationale or None,
    )
    db.add(target)
    db.flush()

    milestone = Milestone(target_id=target.id)
    db.add(milestone)
    db.flush()

    db.add(
        StageChangeLog(
            target_id=target.id,
            previous_stage=None,
            new_stage=milestone.current_stage,
            changed_by=deal_owner or "System",
            change_reason="Initial opportunity creation",
        )
    )
    db.commit()
    db.refresh(target)
    return target


def update_stage(
    db: Session,
    target_id: int,
    new_stage: str,
    changed_by: str | None = None,
    change_reason: str | None = None,
) -> Milestone:
    milestone = db.query(Milestone).filter(Milestone.target_id == target_id).one_or_none()
    if milestone is None:
        milestone = Milestone(target_id=target_id)
        db.add(milestone)
        db.flush()

    previous_stage = milestone.current_stage
    if previous_stage != new_stage:
        milestone.current_stage = new_stage
        milestone.stage_entered_at = datetime.utcnow()
        milestone.updated_at = datetime.utcnow()
        db.add(
            StageChangeLog(
                target_id=target_id,
                previous_stage=previous_stage,
                new_stage=new_stage,
                changed_by=changed_by or "Unknown",
                change_reason=change_reason or None,
            )
        )
        target = db.query(Target).filter(Target.id == target_id).one_or_none()
        if target:
            target.updated_at = datetime.utcnow()

    db.commit()
    db.refresh(milestone)
    return milestone


def log_interaction(
    db: Session,
    target_id: int,
    interaction_type: str,
    summary: str,
    participants_internal: str | None = None,
    participants_external: str | None = None,
    sentiment: str | None = None,
    promoter_willingness: str | None = None,
    valuation_signal: str | None = None,
    created_by: str | None = None,
) -> Interaction:
    interaction = Interaction(
        target_id=target_id,
        interaction_type=interaction_type,
        summary=summary.strip(),
        participants_internal=participants_internal or None,
        participants_external=participants_external or None,
        sentiment=sentiment or None,
        promoter_willingness=promoter_willingness or None,
        valuation_signal=valuation_signal or None,
        created_by=created_by or None,
    )
    db.add(interaction)
    target = db.query(Target).filter(Target.id == target_id).one_or_none()
    if target:
        target.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(interaction)
    return interaction


def create_action(
    db: Session,
    target_id: int,
    description: str,
    owner: str | None = None,
    due_date=None,
    priority: str = "Medium",
    interaction_id: int | None = None,
) -> ActionItem:
    action = ActionItem(
        target_id=target_id,
        interaction_id=interaction_id,
        description=description.strip(),
        owner=owner or None,
        due_date=due_date,
        priority=priority,
        status="Open",
    )
    db.add(action)
    target = db.query(Target).filter(Target.id == target_id).one_or_none()
    if target:
        target.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(action)
    return action
