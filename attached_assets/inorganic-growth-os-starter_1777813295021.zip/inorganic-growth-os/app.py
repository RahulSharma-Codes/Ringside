import os
from datetime import date

import pandas as pd
import streamlit as st

from database import get_session, init_db
from models import ActionItem, Interaction, LookupValue, Milestone, Target
from seed import seed_lookups
from services import create_action, create_target, log_interaction, update_stage

st.set_page_config(page_title="Inorganic Growth Pipeline", page_icon="📈", layout="wide")


@st.cache_resource
def boot_database():
    init_db()
    seed_lookups()
    return True


def require_login():
    expected_password = os.getenv("APP_PASSWORD")
    if not expected_password:
        st.error("APP_PASSWORD is not configured. Add it in Replit Secrets.")
        st.stop()

    if "authenticated" not in st.session_state:
        st.session_state.authenticated = False

    if not st.session_state.authenticated:
        st.title("Inorganic Growth Operating System")
        st.caption("Confidential Corporate Development Platform")
        password = st.text_input("Access Password", type="password")
        if st.button("Login", use_container_width=True):
            if password == expected_password:
                st.session_state.authenticated = True
                st.rerun()
            else:
                st.error("Invalid password.")
        st.stop()


def get_lookup_values(db, category: str):
    rows = (
        db.query(LookupValue)
        .filter(LookupValue.category == category, LookupValue.is_active == True)
        .order_by(LookupValue.sort_order.asc())
        .all()
    )
    return [row.value for row in rows]


def get_latest_interaction(db, target_id: int):
    return (
        db.query(Interaction)
        .filter(Interaction.target_id == target_id)
        .order_by(Interaction.interaction_datetime.desc())
        .first()
    )


def get_open_actions(db, target_id: int):
    return (
        db.query(ActionItem)
        .filter(ActionItem.target_id == target_id, ActionItem.status.in_(["Open", "In Progress", "Blocked"]))
        .order_by(ActionItem.due_date.asc().nulls_last())
        .all()
    )


def render_target_card(db, target: Target):
    milestone = target.milestone
    latest_interaction = get_latest_interaction(db, target.id)
    open_actions = get_open_actions(db, target.id)
    stage = milestone.current_stage if milestone else "Sourcing"
    latest_update = latest_interaction.summary if latest_interaction else "No interaction logged yet."

    with st.container(border=True):
        left, right = st.columns([3, 1])
        with left:
            st.subheader(target.project_name)
            st.caption(f"{target.target_code} | {target.sector or 'Sector N/A'} | {target.country or 'Country N/A'}")
            st.write(target.strategic_rationale or "No strategic rationale captured yet.")
        with right:
            st.metric("Priority Score", target.priority_score)
            st.write(f"**Stage:** {stage}")
            st.write(f"**Tier:** {target.priority_tier}")

        st.divider()
        st.write("**Latest Update**")
        st.write(latest_update)

        if open_actions:
            st.write("**Open Actions**")
            for action in open_actions[:3]:
                due = action.due_date.strftime("%d %b %Y") if action.due_date else "No due date"
                st.write(f"- {action.description} - {action.owner or 'Unassigned'} - {due}")
        else:
            st.write("**Open Actions:** None")

        with st.expander("Update this opportunity"):
            tab1, tab2, tab3 = st.tabs(["Update Stage", "Log Interaction", "Add Action"])

            with tab1:
                stages = get_lookup_values(db, "pipeline_stage")
                new_stage = st.selectbox(
                    "New Stage",
                    stages,
                    index=stages.index(stage) if stage in stages else 0,
                    key=f"stage_{target.id}",
                )
                reason = st.text_area("Reason for stage change", key=f"reason_{target.id}")
                changed_by = st.text_input("Changed by", value=target.deal_owner or "", key=f"changed_by_{target.id}")
                if st.button("Save Stage Change", key=f"save_stage_{target.id}", use_container_width=True):
                    update_stage(db, target.id, new_stage, changed_by, reason)
                    st.success("Stage updated and audit log recorded.")
                    st.rerun()

            with tab2:
                interaction_type = st.selectbox(
                    "Interaction Type",
                    get_lookup_values(db, "interaction_type"),
                    key=f"interaction_type_{target.id}",
                )
                summary = st.text_area(
                    "Meeting / Call Summary",
                    placeholder="Capture the key update, seller signal, valuation signal, risks, and next steps.",
                    key=f"summary_{target.id}",
                )
                sentiment = st.selectbox("Sentiment", ["Positive", "Neutral", "Negative", "Unknown"], key=f"sentiment_{target.id}")
                created_by = st.text_input("Logged by", value=target.deal_owner or "", key=f"created_by_{target.id}")
                if st.button("Log Interaction", key=f"log_interaction_{target.id}", use_container_width=True):
                    if not summary.strip():
                        st.warning("Please enter an interaction summary.")
                    else:
                        log_interaction(db, target.id, interaction_type, summary, sentiment=sentiment, created_by=created_by)
                        st.success("Interaction logged.")
                        st.rerun()

            with tab3:
                description = st.text_area("Action Description", key=f"action_desc_{target.id}")
                owner = st.text_input("Owner", value=target.deal_owner or "", key=f"action_owner_{target.id}")
                due_date = st.date_input("Due Date", value=None, key=f"due_date_{target.id}")
                priority = st.selectbox("Priority", get_lookup_values(db, "action_priority"), key=f"action_priority_{target.id}")
                if st.button("Create Action", key=f"create_action_{target.id}", use_container_width=True):
                    if not description.strip():
                        st.warning("Please enter an action description.")
                    else:
                        create_action(db, target.id, description, owner=owner, due_date=due_date, priority=priority)
                        st.success("Action created.")
                        st.rerun()


def render_add_target_form(db):
    st.header("Add New Opportunity")
    with st.form("add_target_form"):
        target_code = st.text_input("Target Code", placeholder="TGT-0001 or Project Mercury")
        project_name = st.text_input("Project / Target Name")
        sector = st.text_input("Sector")
        country = st.text_input("Country")
        deal_owner = st.text_input("Deal Owner")
        priority_values = get_lookup_values(db, "priority_tier")
        priority_tier = st.selectbox("Priority Tier", priority_values, index=3 if len(priority_values) > 3 else 0)
        strategic_rationale = st.text_area("Strategic Rationale", placeholder="One-line inorganic growth thesis.")
        submitted = st.form_submit_button("Create Opportunity", use_container_width=True)
        if submitted:
            if not target_code.strip() or not project_name.strip():
                st.error("Target Code and Project Name are required.")
            else:
                try:
                    create_target(db, target_code, project_name, sector, country, deal_owner, priority_tier, strategic_rationale)
                    st.success("Opportunity created.")
                    st.rerun()
                except Exception as exc:
                    db.rollback()
                    st.error(f"Could not create opportunity. Check if Target Code already exists. Details: {exc}")


def render_pipeline(db):
    st.header("Active Inorganic Growth Pipeline")
    targets = db.query(Target).filter(Target.is_active == True).order_by(Target.updated_at.desc()).all()
    if not targets:
        st.info("No active opportunities yet. Add your first opportunity from the sidebar.")
        return

    filter_col1, filter_col2, filter_col3 = st.columns(3)
    with filter_col1:
        sectors = sorted({t.sector for t in targets if t.sector})
        selected_sector = st.selectbox("Sector Filter", ["All"] + sectors)
    with filter_col2:
        tiers = sorted({t.priority_tier for t in targets if t.priority_tier})
        selected_tier = st.selectbox("Priority Filter", ["All"] + tiers)
    with filter_col3:
        search = st.text_input("Search", placeholder="Project, company, country...")

    filtered = targets
    if selected_sector != "All":
        filtered = [t for t in filtered if t.sector == selected_sector]
    if selected_tier != "All":
        filtered = [t for t in filtered if t.priority_tier == selected_tier]
    if search:
        q = search.lower()
        filtered = [
            t
            for t in filtered
            if q in t.project_name.lower()
            or q in t.target_code.lower()
            or q in (t.country or "").lower()
            or q in (t.sector or "").lower()
        ]

    st.caption(f"{len(filtered)} active opportunities displayed")
    for target in filtered:
        render_target_card(db, target)


def render_dashboard(db):
    st.header("Executive Dashboard")
    targets = db.query(Target).filter(Target.is_active == True).all()
    milestones = db.query(Milestone).all()
    actions = db.query(ActionItem).filter(ActionItem.status.in_(["Open", "In Progress", "Blocked"])).all()
    overdue_actions = [a for a in actions if a.due_date is not None and a.due_date < date.today()]

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Active Pipeline", len(targets))
    c2.metric("Must-Win Assets", len([t for t in targets if t.priority_tier == "Must-Win"]))
    c3.metric("Open Actions", len(actions))
    c4.metric("Overdue Actions", len(overdue_actions))

    st.subheader("Pipeline by Stage")
    stage_rows = []
    active_target_ids = {t.id for t in targets}
    for milestone in milestones:
        if milestone.target_id in active_target_ids:
            stage_rows.append({"Stage": milestone.current_stage, "Count": 1})
    if stage_rows:
        df = pd.DataFrame(stage_rows)
        stage_counts = df.groupby("Stage", as_index=False).sum()
        st.bar_chart(stage_counts, x="Stage", y="Count")
    else:
        st.info("No milestone data available.")

    st.subheader("Priority-Ranked Must-Win Assets")
    ranked = sorted(targets, key=lambda t: t.priority_score, reverse=True)[:5]
    for target in ranked:
        with st.container(border=True):
            st.write(f"**{target.project_name}**")
            st.caption(f"{target.sector or 'Sector N/A'} | {target.country or 'Country N/A'}")
            st.progress(target.priority_score / 100)
            st.write(f"Priority Score: **{target.priority_score}**")
            st.write(target.strategic_rationale or "No rationale captured.")


def main():
    boot_database()
    require_login()
    db = get_session()
    try:
        st.sidebar.title("Inorganic Growth OS")
        page = st.sidebar.radio("Navigate", ["Pipeline", "Add Opportunity", "Executive Dashboard"])
        if page == "Pipeline":
            render_pipeline(db)
        elif page == "Add Opportunity":
            render_add_target_form(db)
        elif page == "Executive Dashboard":
            render_dashboard(db)
    finally:
        db.close()


if __name__ == "__main__":
    main()
