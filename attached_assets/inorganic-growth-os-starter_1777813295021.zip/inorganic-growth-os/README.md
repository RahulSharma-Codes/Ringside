# Inorganic Growth Operating System

A Streamlit + SQLAlchemy app for managing a confidential inorganic growth / M&A pipeline.

## What this app includes

- Password-protected login
- Active Inorganic Growth Pipeline
- Mobile-friendly card view, one opportunity per card
- Add New Opportunity form
- Stage update workflow with timestamped audit log
- Interaction logging for meetings, calls, banker updates, and mobile notes
- Action tracking with owners and due dates
- Executive dashboard with core pipeline KPIs

## Required Replit Secrets

Add these in Replit Secrets:

```text
DATABASE_URL=your Supabase or Replit Postgres connection string
APP_PASSWORD=your private app login password
```

Do not paste real secrets into source files.

## Run command

```bash
streamlit run app.py --server.address=0.0.0.0 --server.port=8501
```

## First run

The app automatically creates the database tables and lookup values on first run.

## Suggested next features

1. Financial snapshot forms
2. Deal detail page
3. Timeline page
4. Supabase Auth or Replit Auth
5. Document storage for NDA/CIM/DD materials
6. AI-assisted mobile note parsing
